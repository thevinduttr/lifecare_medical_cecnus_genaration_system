import pandas as pd
import json
import time
import os
from src.utils.load_yaml import BROKER_ID, ATTACHMENTS_SAVE_DIR

from src.services.db_config.config import DB_HOST, DB_NAME, DB_USER, DB_PASSWORD
from src.services.db_config.db_connect import MySQLDatabase

from src.services.db_service.db_file_download import process_download_cencus
from src.services.db_service.db_file_download import process_download_tob
from src.services.db_service.db_file_download import process_download_trade_license

# Constants for processing
SLEEP_INTERVAL = 5  # Seconds to wait before checking for new requests

def fetch_pending_requests():
    """
    Fetch pending medical requests directly from the database, return the first pending request.
    
    Returns:
        dict or None: The first pending request dictionary or None if none found.
    """
    try:
        # Connect to the database
        db = MySQLDatabase(DB_HOST, DB_NAME, DB_USER, DB_PASSWORD)
        if not db.connect():
            print("Failed to connect to database")
            return None
        
        # Query to get pending requests sorted by Req_Id
        query = """
        SELECT * FROM medical_cloud_requests 
        WHERE broker_id = %s AND status = 'pending' 
        ORDER BY Req_Id ASC
        """
        
        data = db.fetch_all(query, (BROKER_ID,))
        db.disconnect()
        
        if not data or len(data) == 0:
            print("No pending requests found.")
            return None
        
        # Return the first pending request
        return data[0]
    
    except Exception as e:
        print(f"Database query failed: {e}")
        return None

def update_request_status(req_id, new_status):
    """
    Update the status of a medical request directly in the database.
    
    Args:
        req_id (int): The Req_Id of the request to update.
        new_status (str): The new status to set (e.g., "In Progress", "Completed").
        
    Returns:
        bool: True if update was successful, False otherwise.
    """
    try:
        # Connect to the database
        db = MySQLDatabase(DB_HOST, DB_NAME, DB_USER, DB_PASSWORD)
        if not db.connect():
            print("Failed to connect to database")
            return False
        
        # Update the status
        data = {"status": new_status}
        condition = f"Req_Id = {req_id}"
        result = db.update_record("medical_cloud_requests", data, condition)
        db.disconnect()
        
        if result:
            print(f"Successfully updated Req_Id {req_id} to status '{new_status}'.")
            return True
        else:
            print(f"Failed to update Req_Id {req_id} to status '{new_status}'.")
            return False
            
    except Exception as e:
        print(f"Database update failed for Req_Id {req_id}: {e}")
        return False

def parse_general_data(general_data_json):
    """
    Parse the generalData part of Req_Data into a pandas DataFrame with KEY and VALUE columns.
    
    Args:
        general_data_json (dict): The generalData JSON object.
        
    Returns:
        pd.DataFrame: DataFrame containing KEY and VALUE columns.
    """
    try:
        if isinstance(general_data_json, dict):
            # Flatten the general_data_json
            flat_data = {}
            for key, value in general_data_json.items():
                # If value is list or dict, convert it to JSON string
                if isinstance(value, (list, dict)):
                    flat_data[key] = json.dumps(value)
                else:
                    flat_data[key] = value
            # Create a DataFrame with two columns: KEY and VALUE
            df = pd.DataFrame(list(flat_data.items()), columns=['KEY', 'VALUE'])
            print("Parsed generalData into KEY-VALUE DataFrame.")
            return df
        else:
            print("generalData is not a dictionary.")
            return pd.DataFrame()
    except Exception as e:
        print(f"Error parsing generalData: {e}")
        return pd.DataFrame()

def parse_individual_data_list(individual_data_list_json):
    """
    Parse the individualDataList part of Req_Data into a pandas DataFrame without filtering by company.
    
    Args:
        individual_data_list_json (list): List of dictionaries from individualDataList.
        
    Returns:
        pd.DataFrame: DataFrame containing individual data.
    """
    try:
        if isinstance(individual_data_list_json, list) and len(individual_data_list_json) > 0:
            df = pd.json_normalize(individual_data_list_json)
            print("Parsed individualDataList into DataFrame.")
            return df
        else:
            print("individualDataList JSON is empty or not a list.")
            return pd.DataFrame()
    except Exception as e:
        print(f"Error parsing individualDataList: {e}")
        return pd.DataFrame()

def fetch_medical_data(request):
    """
    Fetch and parse medical data for a specific request.
    
    Args:
        request (dict): The request dictionary.
    
    Returns:
        tuple: (df_general, df_individual)
    """
    # Parse Req_Data from JSON string if it's stored as a string in the database
    if isinstance(request.get('Req_Data'), str):
        req_data_json = json.loads(request.get('Req_Data', '{}'))
    else:
        req_data_json = request.get('Req_Data', {})
    
    general_data_json = req_data_json.get('generalData', {})
    individual_data_list_json = req_data_json.get('individualDataList', [])
    
    df_general = parse_general_data(general_data_json)
    df_individual = parse_individual_data_list(individual_data_list_json)
    
    return df_general, df_individual

def save_to_excel(req_id, df_general, df_individual):
    """
    Save df_individual (Sheet2) and df_general (Sheet1) to an Excel file named MQ_{Req_Id}.xlsx
    with specific column ordering in Sheet2 and KEY-VALUE format in Sheet1.
    
    Args:
        req_id (int): The Req_Id of the request.
        df_general (pd.DataFrame): DataFrame containing general data (KEY, VALUE).
        df_individual (pd.DataFrame): DataFrame containing individual data.
    """
    file_name = f"Medical__NBQ{req_id}.xlsx"
    # If needed, specify a different directory:
    output_dir = ATTACHMENTS_SAVE_DIR
    file_path = os.path.join(output_dir, file_name)
    
    with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
        # Sheet2 = df_individual with specific column ordering
        desired_columns = ["Category", "Company", "TPA", "Network"]
        # Ensure these columns exist in df_individual
        existing_desired_columns = [col for col in desired_columns if col in df_individual.columns]
        other_columns = [col for col in df_individual.columns if col not in existing_desired_columns]
        ordered_columns = existing_desired_columns + other_columns
        df_individual_ordered = df_individual[ordered_columns]
        
        df_individual_ordered.to_excel(writer, sheet_name='Sheet2', index=False)
        
        # Sheet1 = df_general as KEY-VALUE
        if not df_general.empty:
            df_general.to_excel(writer, sheet_name='Sheet1', index=False)
        else:
            # If df_general is empty, create an empty Sheet1 with headers
            pd.DataFrame(columns=['KEY', 'VALUE']).to_excel(writer, sheet_name='Sheet1', index=False)
        
    print(f"Data saved to {file_path}")

def read_and_process_requests(id):
    """
    Continuously fetch, update, and process pending medical requests one by one in ascending order.
    
    Args:
        id (str): Identifier for processing. Typically 'default'.
    
    Returns:
        None
    """
    if id == 'default':
        print("\nFetching pending medical requests...")
        request = fetch_pending_requests()
        
        if not request:
            print("No pending medical requests found. Waiting for new requests...")
            time.sleep(SLEEP_INTERVAL)
            return False  # Wait and fetch again
        
        req_id = request.get('Req_Id')
        status = request.get('status', '').lower()
        
        if status != "pending":
            print(f"Req_Id {req_id} has status '{status}'. Skipping.")
            return False  # Skip non-pending requests
            
        process_download_cencus(req_id)
        process_download_tob(req_id)
        process_download_trade_license(req_id)
        
        print(f"\nProcessing Req_Id {req_id}...")
        
        # Update status to "In Progress"
        if not update_request_status(req_id, "In Progress"):
            print(f"Failed to update status for Req_Id {req_id}. Skipping processing.")
            return False  # Skip processing if status update fails
        
        # Fetch and parse medical data
        df_general, df_individual = fetch_medical_data(request)
        
        # Display the DataFrames (optional)
        if not df_general.empty:
            print("df_general (General Data):")
            print(df_general)
        else:
            print("df_general is empty.")
        
        if not df_individual.empty:
            print("df_individual (Individual Data):")
            print(df_individual)
        else:
            print("df_individual is empty.")
        
        # Save to Excel file named MQ_{Req_Id}.xlsx
        save_to_excel(req_id, df_general, df_individual)
        
        return req_id
        
    else:
        print(f"Unhandled id: {id}. No action taken.")
        return False