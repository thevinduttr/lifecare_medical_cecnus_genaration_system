import base64
import os
from src.utils.load_yaml import BROKER_ID, ATTACHMENTS_SAVE_DIR

from src.services.db_config.config import DB_HOST, DB_NAME, DB_USER, DB_PASSWORD
from src.services.db_config.db_connect import MySQLDatabase

# Function to save a file from a base64 string
def save_base64_to_file(base64_string, output_file_path):
    try:
        # Decode the base64 string to binary data
        file_data = base64.b64decode(base64_string)
        
        # Write the binary data to a file
        with open(output_file_path, 'wb') as file:
            file.write(file_data)
        
        print(f"File saved successfully as {output_file_path}")
    
    except Exception as e:
        print(f"An error occurred while saving the file {output_file_path}: {e}")

# Function to fetch a request directly from the database
def fetch_request_from_db(req_id):
    try:
        # Connect to the database
        db = MySQLDatabase(DB_HOST, DB_NAME, DB_USER, DB_PASSWORD)
        if not db.connect():
            print("Failed to connect to database")
            return None
        
        # Query to get the request with the specified req_id
        query = """
        SELECT * FROM medical_cloud_requests 
        WHERE Req_Id = %s
        """
        
        request = db.fetch_one(query, (req_id,))
        db.disconnect()
        
        if not request:
            print(f"No request found with Req_Id {req_id}")
            return None
        
        return request
    
    except Exception as e:
        print(f"Database query failed: {e}")
        return None

# Function to process a request by Req_Id and download the Census_Data as an Excel file
def process_download_cencus(req_id):
    # Fetch request from the database
    request = fetch_request_from_db(req_id)
    
    if request:
        # Check for Census_Data field and save it as an Excel file
        census_data = request.get('Census_Data')
        if census_data:
            output_folder = ATTACHMENTS_SAVE_DIR
            # Ensure the directory exists
            os.makedirs(output_folder, exist_ok=True)
            
            # Define the output file path
            output_file_path = os.path.join(output_folder, "CensusData-TEMPLATE_Common with Nationality.xlsx")
            save_base64_to_file(census_data, output_file_path)
        else:
            print("No Census_Data found for the given request.")
    else:
        print(f"Failed to fetch request with Req_Id {req_id}")

# Function to process a request by Req_Id and download the TOB as a PDF file
def process_download_tob(req_id):
    # Fetch request from the database
    request = fetch_request_from_db(req_id)
    
    if request:
        # Check for TOB field and save it as a PDF file
        tob_data = request.get('TOB')
        if tob_data:
            output_folder = ATTACHMENTS_SAVE_DIR
            # Ensure the directory exists
            os.makedirs(output_folder, exist_ok=True)
            
            # Define the output file path
            output_file_path = os.path.join(output_folder, "tob.pdf")
            save_base64_to_file(tob_data, output_file_path)
        else:
            print("No TOB found for the given request.")
    else:
        print(f"Failed to fetch request with Req_Id {req_id}")

# Function to process a request by Req_Id and download the Trade_License_Doc as a PDF file
def process_download_trade_license(req_id):
    # Fetch request from the database
    request = fetch_request_from_db(req_id)
    
    if request:
        # Check for Trade_License_Doc field and save it as a PDF file
        trade_license_data = request.get('Trade_License_Doc')
        if trade_license_data:
            output_folder = ATTACHMENTS_SAVE_DIR
            # Ensure the directory exists
            os.makedirs(output_folder, exist_ok=True)
            
            # Define the output file path
            output_file_path = os.path.join(output_folder, "Trade License.pdf")
            save_base64_to_file(trade_license_data, output_file_path)
        else:
            print("No Trade License found for the given request.")
    else:
        print(f"Failed to fetch request with Req_Id {req_id}")