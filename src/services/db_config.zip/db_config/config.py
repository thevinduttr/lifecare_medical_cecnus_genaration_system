# MySQL Database Configuration
# These values should ideally be imported from your yaml config
DB_HOST = "localhost"
DB_NAME = "newwebdb"
DB_USER = "rpa_medical_user"
DB_PASSWORD = "Rpa$2025Algo&MeDical"